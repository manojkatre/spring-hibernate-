package com.yash;
import java.util.List;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SearchUser {
 public static void main(String s[])
 {
	 ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationcontext1.xml");
	UserDAO udao = (UserDAO) objAC.getBean("userdao");
	
	User u=udao.getUserById(1);
		
		System.out.println(u.getAdd1() +"---"+  u.getAdd2());
		/*List<Employee> ulist=udao.getAllEmp();
		
		System.out.println("Empid\t Name \t Salary");
		for(Employee e: elist)
		{
			System.out.println(e.getId()+"\t"+e.getEname()+" \t "+e.getSalary());			
		}*/
 }
}
