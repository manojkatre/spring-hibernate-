package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class UserMainDemo {
	public static void main(String s[])
	{
			ApplicationContext objAC = new ClassPathXmlApplicationContext("applicationcontext1.xml");
			UserDAO userdao = (UserDAO) objAC.getBean("userdao");
			User objU = new User();
			objU.setUserid(2);
			objU.setPassword("pass@123");
			objU.setFirstname("rahul");
			objU.setLastname("sharma");
			objU.setMobile(8888);
			objU.setDOB("13april1990");
			objU.setEmail("rahul.com");
			objU.setCity("akola");
			objU.setAdd1("mg road");
			objU.setAdd2("pune ");
			
			
			
			
			
			userdao.saveUser(objU);
	}
}
